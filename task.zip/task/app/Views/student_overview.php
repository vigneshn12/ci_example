<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Curd</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">
	
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/css/bootstrap.min.css'>
	<link rel='stylesheet' href='<?php echo base_url("/css/style.css");?>'>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

</head>
<body>

	<div class="global-container">
		<div class="card login-form" style="width: 100%;">
			<div class="card-body">
				<h3 class="card-title text-center">Student list</h3>
				<div style="text-align: right;"><a href="<?=base_url('backend/exportcsv');?>">Export csv</a></div><br/>
				<div style="text-align: right;"><a href="<?=base_url('backend');?>">Add Student</a></div>
				<div class="card-text">
					<table class="table">
					  <thead>
						<tr>
						  <th scope="col">#</th>
						  <th scope="col">Name</th>
						  <th scope="col">Father name</th>
						  <th scope="col">Gender</th>
						  <th scope="col">Country</th>
						  <th scope="col">States</th>
						  <th scope="col">Photo</th>
						  <th scope="col">Email</th>
						  <th scope="col">Number</th>
						  <th scope="col">Educational Qualification</th>
						  <th scope="col">Hobbies</th>
						  <th scope="col">Actions</th>
						</tr>
					  </thead>
					  <tbody>
					  <?php if(!empty($getstudent)){ foreach($getstudent as $key => $res){?>
						<tr>
						  <th scope="row"><?=$key+1;?></th>
						  <td><?=$res->name;?></td>
						  <td><?=$res->father_name;?></td>
						  <td><?=$res->gender;?></td>
						  <td><?=$res->country;?></td>
						  <td><?=$res->states;?></td>
						  <td><img src="<?=base_url("/uploads/photo/".$res->photo);?>" alt="<?=$res->name;?>" width="200px"/></td>
						  <td><?=$res->email;?></td>
						  <td><?=$res->number;?></td>
						  <td>
						  <?php
							$this->db = \Config\Database::connect();
							$builder = $this->db->table('educational_details');
							$builder->where('student_id', $res->id);
							$educational = $builder->get()->getrow();
						  ?>
						  Qualification : <?php echo $educational->qualification;?><br>
						  Month & Year of passing : <?php echo $educational->passing_year_month;?><br>
						  Name of the University : <?php echo $educational->university_name;?><br>
						  </td>
						  <td><?php $vr = explode(',',$res->hobbies); if(!empty($vr)){ foreach($vr as $re){ echo $re; echo'<br/>'; } } ?></td>
						  <td><a href="<?=base_url('backend/student_delete/?id='.$res->id);?>">Delete</a></td>
						</tr>
					  <?php } } else {?>
						<tr>
						  <td colspan="12" class="text-center">NO DATA FOUND</td>
						</tr>
					  <?php } ?>
					  </tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	
	
</body>
</html>
