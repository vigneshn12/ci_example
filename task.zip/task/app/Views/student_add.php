<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Curd</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">
	
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/css/bootstrap.min.css'>
	<link rel='stylesheet' href='<?php echo base_url("/css/style.css");?>'>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

</head>
<body>

	<div class="global-container">
		<div class="card login-form">
			<div class="card-body">
				<h3 class="card-title text-center">Create Student</h3>
				<div style="text-align: right;"><a href="<?=base_url('backend/student_overview');?>">Student overview list</a></div>
				<div class="card-text">
					<?php echo form_open_multipart("", array("id"=>"student_validation",'data-toggle'=> "validator"));?>
						<div class="form-group">
							<label for="exampleInputName">Name</label>
							<input type="text" name="name" class="form-control form-control-sm" id="exampleInputName" required>
						</div>
						<div class="form-group">
							<label for="exampleInputdate">Date</label>
							<input type="date" name="date" class="form-control form-control-sm" id="exampleInputdate" required>
						</div>
						<div class="form-group">
							<label for="exampleInputFather">Father's Name</label>
							<input type="text" name="father_name" class="form-control form-control-sm" id="exampleInputFather" required>
						</div>
						<div class="form-group">
							<label for="exampleInputFather" style="padding-right: 40px;">Gender</label>
							<input type="radio" name="gender" class="form-control form-control-sm" value="male" style="text-align: left;display: inline-block;width: auto;">
							<label for="Male">Male</label>
							<input type="radio" name="gender" class="form-control form-control-sm" value="female" style="text-align: left;display: inline-block;width: auto;">
							<label for="female">Female</label>
						</div>
						<div class="form-group">
							<label for="exampleInputCountry">Country</label>
							<select name="country" id="Country" style="padding: 0.25rem 0.5rem;font-size: .875rem;line-height: 1.5;border-radius: 0.2rem;width: 100%;" required>
							<?php if($getcountry){ foreach($getcountry as $key => $res){?>
							  <option value="<?=$res->country_name;?>"><?=$res->country_name;?></option>
							<?php } } ?>
							</select>
						</div>
						<div class="form-group">
							<label for="exampleInputstates">States</label>
							<select name="states" id="States" style="padding: 0.25rem 0.5rem;font-size: .875rem;line-height: 1.5;border-radius: 0.2rem;width: 100%;" required>
							  <option>No States available</option>
							</select>
						</div>
						<div class="form-group">
							<label for="exampleInputphoto">Photo</label>
							<input type="file" name="photo" class="form-control form-control-sm" accept="image/png, image/jpeg" required>
						</div>
						<div class="form-group">
							<label for="exampleInputemail">Email-id</label>
							<input type="email" name="email" class="form-control form-control-sm" required>
						</div>
						<div class="form-group">
							<label for="exampleInputnumber">Phone Number</label>
							<input type="number" name="number" class="form-control form-control-sm" required>
						</div>
						<div class="form-group">
							<label for="exampleInputhobbies">Hobbies</label><br/>
							<input type="checkbox" name="hobbies[]" value="Reading" class="form-control form-control-sm" style="width: auto;float: left;margin: 5px;"> <label>Reading</label><br/>
							<input type="checkbox" name="hobbies[]" value="Dancing" class="form-control form-control-sm" style="width: auto;float: left;margin: 5px;"> <label>Dancing</label><br/>
							<input type="checkbox" name="hobbies[]" value="Singing" class="form-control form-control-sm" style="width: auto;float: left;margin: 5px;"> <label>Singing</label><br/>
							<input type="checkbox" name="hobbies[]" value="Playing" class="form-control form-control-sm" style="width: auto;float: left;margin: 5px;"> <label>Playing</label><br/>
						</div>
						<div class="form-group">
							<label for="exampleInputeducational">Educational Qualification</label>
							
							<table class="morerow" border='1'>
								  <tr>
									<th>Qualification</th>
									<th>Month & Year of passing</th>
									<th>Name of the University</th>
									<th>Delete</th>
								  </tr>
								  <tr>
									<td><input type="text" name="qualification[]" class="form-control form-control-sm"></td>
									<td><input type="text" name="passing_year_month[]" class="form-control form-control-sm"></td>
									<td><input type="text" name="university_name[]" class="form-control form-control-sm"></td>
									<td><span class="add_icon">Add</span></td>
								  </tr>
							</table>
						</div>
						<button type="submit" class="btn btn-primary btn-block">Submit</button>
					<?php echo form_close(); ?>
				</div>
			</div>
		</div>
	</div>
	
	
<script>
$(document).ready(function(){
	$("#Country").on("change",function(){
		
		var getcountry = $(this).val();
		$.ajax({
			url : '<?php echo base_url("/backend/getstates");?>',
			type : "get",
			data : { "country_name":getcountry},
			success : function(data)
			{
				$('#States').html(data);
			}
		});
	});
});
</script>


<script>
$(document).on('click', '.add_icon', function() {
	$('.morerow').append('<tr><td><input type="text" name="qualification[]" class="form-control form-control-sm"></td><td><input type="text" name="passing_year_month[]" class="form-control form-control-sm"></td><td><input type="text" name="university_name[]" class="form-control form-control-sm"></td><td><span class="del_icon">Delete</span></td></tr>');
	
});
</script>


<script>
$(document).on('click', '.del_icon', function() {
	$(this).parent().parent('tr').remove();
});
</script>
	
</body>
</html>
