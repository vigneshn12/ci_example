<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
		echo'<pre>'; print_r('test'); echo'';
		exit;
        return view('welcome_message');
    }
	
	public function student_add()
    {
		
		echo'<pre>'; print_r('test'); echo'';
		exit;
        return view('student_add');
    }
}
