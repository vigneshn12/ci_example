<?php

namespace App\Controllers;

class Backend extends BaseController
{
	
	function __construct()
	{
		$this->db = \Config\Database::connect(); 
	}
	
	
    public function index()
    {
		
		if($this->request->getPost()){
			$data = $this->request->getPost();
			$data['hobbies'] = implode(',',$data['hobbies']);
			
			if(!empty($_FILES['photo']['name'])){
				if($file = $this->request->getFile('photo')){
					if (!$file->hasMoved()) {
						$name = $file->getName();
						$ext = $file->getClientExtension();
						$data['photo'] = $file->getRandomName();   	     
						$file->move('./uploads/photo/',$data['photo']);
					}
				}
			}
			
			if(!empty($data)){
				unset($data['qualification']);
				unset($data['university_name']);
				unset($data['passing_year_month']);
				$builder = $this->db->table('student');
				$builder->set($data);
				$builder->insert($data);
				$get_id = $this->db->insertID();
			}
			
			$qual = $this->request->getPost('qualification');
			$qual_y = $this->request->getPost('passing_year_month');
			$qual_n = $this->request->getPost('university_name');
			
			for($i=0;$i<count($this->request->getPost('qualification')); $i++)
			{
				if(!empty($qual[$i]))
				{
					$data1['student_id	'] = $get_id;
					$data1['qualification'] = $qual[$i];
					$data1['passing_year_month'] = $qual_y[$i];
					$data1['university_name'] = $qual_n[$i];
					$builder = $this->db->table('educational_details');
					$builder->set($data1);
					$builder->insert($data1);
				}
			}
			
			return redirect()->to('/backend/student_overview');
		}

		$builder = $this->db->table('country');
		$result = $builder->get()->getresult();
		$this->outputData['getcountry'] = $result;
        return view('student_add', $this->outputData);
    }
	
	public function student_overview()
    {
		$builder = $this->db->table('student');
		$result = $builder->get()->getresult();
		$this->outputData['getstudent'] = $result;
        return view('student_overview', $this->outputData);
	}
	
	public function student_delete()
    {
		if(!empty($this->request->getGet('id'))){
			$id = $this->request->getGet('id');
			$builder = $this->db->table('student');
			$builder->where('id',$id);
			$builder->delete();
			
			$builder = $this->db->table('educational_details');
			$builder->where('student_id',$id);
			$builder->delete();
			return redirect()->to('/backend/student_overview');
		}
	}
	
	public function getstates()
    {
		if (!$this->request->isAJAX()) {
			return redirect()->to('404');
		}
		
		$country_name = $this->request->getGet('country_name');
		
		$builder = $this->db->table('country');
		$builder->join('states','country.id = states.country_id','right');
		$builder->where('country_name', $country_name);
		$builder->where('states.states !=', '');
		$result = $builder->get()->getresult();
		
		$getallstates = array();
		if(!empty($result)){ foreach($result as $res){
			$getallstates[] =  '<option value="'.$res->states.'">'.$res->states.'</option>';
		} } else {
			$getallstates = '<option>No states available</option>';
		}
		
		return print_r($getallstates);
		exit;
		
	}
	
	public function exportcsv(){
		
		$builder = $this->db->table('student');
		$result = $builder->get()->getresult();
        header("Content-type: application/csv");
        header("Content-Disposition: attachment; filename=\"student".".csv\"");
        header("Pragma: no-cache");
        header("Expires: 0");

        $handle = fopen('php://output', 'w');
        fputcsv($handle, array("No","Name","Father Name","Gender","Country","States","Email","Number","Hobbies"));
        $cnt=1;
        foreach ($result as $key => $val) {
            $narray=array($key+1,$val->name,$val->father_name,$val->gender,$val->country,$val->states,$val->email,$val->number,$val->hobbies);
            fputcsv($handle, $narray);
        }
            fclose($handle);
        exit;
    }
	
}
